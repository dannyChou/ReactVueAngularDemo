﻿import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: '<h1>Angular練習範例</h1>'
})

export class AppComponent {}
