﻿function initial(){
	
	new Vue({
		el: '#msg',
		data: {
			message: 'this is Vue.js sample!'
		}
	})
}
