System.register(["github:frankwallis/plugin-typescript@2.6.0/plugin"], function($__export) {
  return {  setters: [function(m) { for (var p in m) $__export(p, m[p]); }],  execute: function() {}  };
});