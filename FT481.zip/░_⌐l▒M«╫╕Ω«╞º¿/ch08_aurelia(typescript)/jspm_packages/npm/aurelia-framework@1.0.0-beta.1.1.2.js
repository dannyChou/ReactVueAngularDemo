define(["npm:aurelia-framework@1.0.0-beta.1.1.2/aurelia-framework"], function(main) {
  return main;
});