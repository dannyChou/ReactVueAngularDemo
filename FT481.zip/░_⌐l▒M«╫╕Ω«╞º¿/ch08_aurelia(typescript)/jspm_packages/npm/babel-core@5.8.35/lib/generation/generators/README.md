## Generators

Code generation in Babel is broken down into generators by node type, they all
live in this directory.

[TBD: To Be Documented:]

- How generators work
- How to print a node
- How generators related to one another
