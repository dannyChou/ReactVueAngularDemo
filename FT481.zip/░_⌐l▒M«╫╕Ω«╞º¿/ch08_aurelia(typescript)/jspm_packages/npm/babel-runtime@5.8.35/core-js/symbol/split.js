/* */ 
module.exports = { "default": require("core-js/library/fn/symbol/split"), __esModule: true };