/* */ 
module.exports = { "default": require("core-js/library/fn/symbol/for"), __esModule: true };