/* */ 
module.exports = { "default": require("core-js/library/fn/get-iterator"), __esModule: true };