/* */ 
module.exports = { "default": require("core-js/library/fn/number/random"), __esModule: true };