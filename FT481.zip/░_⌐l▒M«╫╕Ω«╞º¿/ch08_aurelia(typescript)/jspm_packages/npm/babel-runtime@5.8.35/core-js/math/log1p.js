/* */ 
module.exports = { "default": require("core-js/library/fn/math/log1p"), __esModule: true };