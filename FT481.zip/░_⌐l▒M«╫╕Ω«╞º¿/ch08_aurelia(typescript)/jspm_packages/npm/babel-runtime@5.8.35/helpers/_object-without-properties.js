/* */ 
module.exports = require('./objectWithoutProperties');
