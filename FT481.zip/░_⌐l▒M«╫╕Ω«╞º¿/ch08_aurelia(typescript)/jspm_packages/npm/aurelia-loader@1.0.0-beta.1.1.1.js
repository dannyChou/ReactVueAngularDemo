define(["npm:aurelia-loader@1.0.0-beta.1.1.1/aurelia-loader"], function(main) {
  return main;
});