define(["npm:aurelia-history-browser@1.0.0-beta.1.1.2/aurelia-history-browser"], function(main) {
  return main;
});