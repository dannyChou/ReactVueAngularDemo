﻿window.onload = function(){
	document.querySelector('#msg').textContent = '此為未使用jQuery的畫面。';
}
